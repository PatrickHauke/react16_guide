import React, { Component } from 'react';
import './App.css';
import Person from './Person/Person';

class App extends Component {
  state = {
    persons: [
      {name: 'Patrick', age: 23},
      {name: 'Kajol', age: 21},
      {name: 'Mishka', age: 8}  
    ]
  }

  switchNameHandler = (newName) => {
    // console.log('clicked');
    // Don't do this way! :: this.state.persons[0].name = "Mat";
    this.setState({persons: [
      {name: 'Patrick', age: 24},
      {name: newName, age: 21},
      {name: 'Mishka', age: 9} 
    ]})
  }

  render() {
    return (
      <div className="App">
        <p>Hello World!</p>
        <button onClick={this.switchNameHandler.bind(this, "Pat")}>Switch Name</button>
        {/* <button onClick={()=> this.switchNameHandler('Pat!!!')}>Switch Name</button> */}
        <Person 
          name={this.state.persons[0].name} 
          age={this.state.persons[0].age} 
          click={this.switchNameHandler}  
        />
        <Person 
          name={this.state.persons[1].name} 
          age={this.state.persons[1].age}
          click={this.switchNameHandler.bind(this, 'Starlight')}  
          >And my hobbie is: Dancing</Person>
        <Person name={this.state.persons[2].name} age={this.state.persons[2].age}/>
      </div>
    );
    // return React.createElement('div', {className: 'App'}, React.createElement('h1', null, 'I\'m a react app'));
  }
}

export default App;
