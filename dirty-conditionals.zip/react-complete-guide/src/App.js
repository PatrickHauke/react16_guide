import React, { Component } from 'react';
import './App.css';
import Person from './Person/Person';


class App extends Component {
  state = {
    persons: [
      {name: 'Patrick', age: 23},
      {name: 'Kajol', age: 21},
      {name: 'Mishka', age: 8}  
    ],
    showPersons: false
  }

  switchNameHandler = (newName) => {
    // console.log('clicked');
    // Don't do this way! :: this.state.persons[0].name = "Mat";
    this.setState({persons: [
      {name: 'Patrick', age: 24},
      {name: newName, age: 21},
      {name: 'Mishka', age: 9} 
    ]})
  }

  nameChangedHandler = (event) => {
    this.setState({persons: [
      {name: 'Patrick', age: 24},
      {name: event.target.value, age: 21},
      {name: 'Mishka', age: 9} 
    ]})
  }

  togglePersonsHandler = (event) => {
    const doesShow = this.state.showPersons;
    // Flip the boolean
    this.setState({showPersons: !doesShow})
  }

  render() {
    const style = {
      backgroundColor: 'white',
      font: 'inherit',
      border: '1px solid blue',
      padding: '8px',
      cursor: 'pointer'
    };

    return (
      <div className="App">
        <p>Hello World!</p>
        <button 
          style = {style}
          onClick={this.togglePersonsHandler}> 
          Toggle Person
        </button>
        {/* <button onClick={()=> this.switchNameHandler('Pat!!!')}>Switch Name</button> */}
        {/* Tunary js. If true, render component. Else, leave null (default) */}
        { this.state.showPersons ?
          <div>
            <Person 
              name={this.state.persons[0].name} 
              age={this.state.persons[0].age} 
              click={this.switchNameHandler}  
            />
            <Person 
              name={this.state.persons[1].name} 
              age={this.state.persons[1].age}
              click={this.switchNameHandler.bind(this, 'Starlight')}  
              changed={this.nameChangedHandler}
              >And my hobbie is: Dancing</Person>
            <Person name={this.state.persons[2].name} age={this.state.persons[2].age}/>
          </div> : null
        }
      </div>
    );
    // return React.createElement('div', {className: 'App'}, React.createElement('h1', null, 'I\'m a react app'));
  }
}

export default App;
